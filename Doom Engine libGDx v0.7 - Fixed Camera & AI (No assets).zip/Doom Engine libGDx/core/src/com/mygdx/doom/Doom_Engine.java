package com.mygdx.doom;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.*;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g3d.*;
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute;
import com.badlogic.gdx.graphics.g3d.attributes.TextureAttribute;
import com.badlogic.gdx.graphics.g3d.environment.PointLight;
import com.badlogic.gdx.graphics.g3d.loader.ObjLoader;
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.utils.ScreenUtils;

import static com.badlogic.gdx.Gdx.*;
import static com.badlogic.gdx.graphics.Color.*;
import static com.mygdx.doom.CameraHandler.main_camera;

public class Doom_Engine extends ApplicationAdapter implements InputProcessor {
	public static ModelBatch modelBatch; //like sprite batch but for models (obviously better for 3D)
	private ModelBuilder modelBuilder; //builds the object together
	private Model ramp_bridge2, box, J_plat, J_plat2,J_plat3, sphere, playermodel, ramp, ramp_bridge, pyramid, hexagon, cone, donut;
	//this is the 3D object - Need to make base objects to then create more complex models.
	public Model bullet, AImodel;
	private Model roof, m_wall, m_wall1, s4_plane, main_plane; //these are to create a room
	// literally an instance of the model - pos, transform
	private ModelInstance MI, MI1, MI2, MI3, MI4, MI5, MI6, MI7, MI8, MI9, MI10, MI11, MI12, MI13, MI14, MI15, MI16, MI17, MI18, MI19,
			MI20, MI21, MI22, MI23, MI24, MI25, MI26, MI27, MI28, MI29, MI30, MI31, MI32, MI33;
	private Environment environment; // this makes shaders/ lighting etc.
	private Vector3 vector1; // static temp vectors for vector maths
	private final PointLight PL = new PointLight();
	private final PointLight PL1 = new PointLight();
	private final PointLight PL2 = new PointLight();
	private final PointLight PL3 = new PointLight();
	private final PointLight PL4 = new PointLight();

	private final ObjLoader obj_loader = new ObjLoader();
	private Texture Metal_Wall_Red_T,Floor_Gravel_T, Metal_Wall_Plain_T,Metal_Wall_Red_Striped_T, Metal_Wall_Dark_T,
			Brick_Wall_T, Brick_Wall_Red_T, Mountain_T, Light_Wood_T, Wood_T, Red_Rocks_T, Crosshair, Bar_Full, Bar_75, Bar_Half,
			Bar_25, Bar_Empty;
	private Material Metal_Wall_Red_M, Floor_Gravel_M, Metal_Wall_Plain_M,Metal_Wall_Red_Striped_M, Metal_Wall_Dark_M,
			Brick_Wall_M, Brick_Wall_Red_M, Mountain_M, Light_Wood_M, Wood_M, Red_Rocks_M;

	private ModelInstance instance_arr_T[]; //maybe need to have seperate ones for BB and then texturing.
	public static ModelInstance[] instance_arr_BB = new ModelInstance[5];
	//Having an Attribute that applies to more than one object without creating a new instance of that attribute is
	//much more efficient, but not to worry yet.
	public static ColorAttribute ambient = new ColorAttribute(ColorAttribute.AmbientLight, 0.4f, 0.4f, 0.4f, 1.0f);
	public static ColorAttribute fog = new ColorAttribute(ColorAttribute.Fog, 60f,60f,60f,0.5f);

	private int mouseX = 0;
	private int mouseY = 0;
	private float rotSpeed = 0.2f;

	@Override
	public void create () {

		CameraHandler.CameraMaker();
		//Texture Loading
		Metal_Wall_Red_T = new Texture("textures/Metal_Wall_Red_Rust.jpg");
		Floor_Gravel_T = new Texture("textures/Floor_Gravel.jpg");
		Metal_Wall_Plain_T = new Texture("textures/Metal_Wall_Plain.JPG");
		Metal_Wall_Red_Striped_T = new Texture("textures/Metal_Wall_Striped_Rust.jpg");
		Metal_Wall_Dark_T = new Texture("textures/Metal_Wall_Dark_Rust.jpg");
		Brick_Wall_T = new Texture("textures/brick_wall.png");
		Brick_Wall_Red_T = new Texture("textures/brick_wall-red.png");
		Mountain_T = new Texture("textures/mountain.png"); //slightly broken - wrong sizing
		Light_Wood_T = new Texture("textures/light_wood.jpg");
		Wood_T = new Texture("textures/wood.jpg");
		Red_Rocks_T = new Texture("textures/RedRocksAndSandB_S.jpg");
		Crosshair = new Texture("textures/TestCrosshair.png");

		//Health Bar/Bar graphics
		Bar_Full = new Texture("textures/Bar_Full.png");
		Bar_75 = new Texture("textures/Bar_75.png");
		Bar_Half = new Texture("textures/Bar_Half.png");
		Bar_25 = new Texture("textures/Bar_25.png");
		Bar_Empty = new Texture("textures/Bar_Empty.png");

		//Material Creation (from Textures)
		Metal_Wall_Red_M = new Material(TextureAttribute.createDiffuse(Metal_Wall_Red_T));
		Floor_Gravel_M = new Material(TextureAttribute.createDiffuse(Floor_Gravel_T));
		Metal_Wall_Plain_M = new Material(TextureAttribute.createDiffuse(Metal_Wall_Plain_T));
		Metal_Wall_Red_Striped_M = new Material(TextureAttribute.createDiffuse(Metal_Wall_Red_Striped_T));
		Metal_Wall_Dark_M = new Material(TextureAttribute.createDiffuse(Metal_Wall_Dark_T));
		Brick_Wall_M = new Material(TextureAttribute.createDiffuse(Brick_Wall_T));
		Brick_Wall_Red_M = new Material(TextureAttribute.createDiffuse(Brick_Wall_Red_T));
		Mountain_M = new Material(TextureAttribute.createDiffuse(Mountain_T));
		Light_Wood_M = new Material(TextureAttribute.createDiffuse(Light_Wood_T));
		Wood_M = new Material(TextureAttribute.createDiffuse(Wood_T));
		Red_Rocks_M = new Material(TextureAttribute.createDiffuse(Red_Rocks_T));

		modelBatch = new ModelBatch();
		modelBuilder  = new ModelBuilder(); //used for .obj loading


		playermodel = modelBuilder.createBox(1f,1.5f, 1f,
				new Material(ColorAttribute.createDiffuse(ORANGE)),VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);
		bullet = modelBuilder.createBox(1f,.1f,.5f, //creates cube, with pos, material, and normal data
				new Material(ColorAttribute.createDiffuse(PINK)), VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);
		ramp_bridge2 = modelBuilder.createBox(72f,.25f,8f,
				new Material(ColorAttribute.createDiffuse(RED)), VertexAttributes.Usage.Position|VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);
		box = modelBuilder.createBox(5f, 5f, 5f,
				new Material(ColorAttribute.createDiffuse(PINK)), VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);
		sphere = modelBuilder.createSphere(5,5,5, 16,32,
				new Material(ColorAttribute.createDiffuse(ORANGE)), VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);
		cone = modelBuilder.createCone(2,2,2,16,
				new Material(ColorAttribute.createDiffuse(PURPLE)), VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);
		J_plat = modelBuilder.createBox(5f, 1.5f, 5f,
				new Material(ColorAttribute.createDiffuse(GREEN)), VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);
		J_plat2 = modelBuilder.createBox(10f, 1.5f, 5f,
				new Material(ColorAttribute.createDiffuse(GREEN)), VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);
		J_plat3 = modelBuilder.createBox(5f, 1.5f, 10f,
				new Material(ColorAttribute.createDiffuse(GREEN)), VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);
		roof = modelBuilder.createBox(100f, 0.1f, 100f,
				new Material(ColorAttribute.createDiffuse(GRAY)), VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);
		m_wall = modelBuilder.createBox(100f, 50f, 1f,
				new Material(ColorAttribute.createDiffuse(GRAY)), VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);
		m_wall1 = modelBuilder.createBox(1f, 50f, 100f,
				new Material(ColorAttribute.createDiffuse(GRAY)), VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);
		ramp_bridge = modelBuilder.createBox(8f, 0.25f, 4f,
				new Material(ColorAttribute.createDiffuse(LIGHT_GRAY)), VertexAttributes.Usage.Position | VertexAttributes.Usage.Normal| VertexAttributes.Usage.TextureCoordinates);

		ramp = obj_loader.loadModel(files.internal("assets/Slope.obj"));
		pyramid = obj_loader.loadModel(files.internal("assets/Pyramid.obj"));
		hexagon = obj_loader.loadModel(files.internal("assets/Hexagon_V1.obj"));
		s4_plane = obj_loader.loadModel(files.internal("assets/section4_plane_part.obj"));
		main_plane = obj_loader.loadModel(files.internal("assets/main_plane_part_V2.obj"));
		donut = obj_loader.loadModel(files.internal("assets/Donut.obj"));
		AImodel = obj_loader.loadModel(files.internal("assets/Player.obj"));

		//*********
		//Design and Object Position
		//*********

		//Section 1 - Design Layout
		MI4 = new ModelInstance(J_plat,-20,0,-25); //jumping platforms #1
		MI13 = new ModelInstance(J_plat, -30,0,-18);//#2
		MI14 = new ModelInstance(J_plat, -30, 0, -28); //#3
		MI15 = new ModelInstance(J_plat2, -24,0,-45);//#4
		MI16 = new ModelInstance(J_plat3,-42,0,-30); //#5

		//bridge
		MI17 = new ModelInstance(ramp,0,-1.5f,-7.1f); //ramp - blender changes height/pos
		MI18 = new ModelInstance(ramp,-21,-1.5f,-20);
		MI19 = new ModelInstance(ramp_bridge,-10.5f,2,-13.5f); //ramp bridge
		MI17.transform.scl(2);
		MI17.transform.rotate(0,90,0,90);

		MI18.transform.scl(2);
		MI18.transform.rotate(0,-90,0,90);
		//test - this works, but only after instantiating the Model instance.

		//Section 2 - Design Layout
		MI20 = new ModelInstance(ramp,12,-2.5f,-45);
		MI20.transform.scl(4); //I want this to be the bigger bridge
		MI20.transform.rotate(0,-90,0,90);

		MI21 = new ModelInstance(pyramid,16,1,-25); //pyramid
		MI21.transform.scl(4); //needs to be large for collision testing

		MI5 = new ModelInstance(sphere,24,2,-20); //sphere
		MI = new ModelInstance(ramp_bridge2, 29.25f,4.75f,0); //section2/3 bridge_ramp
		MI.transform.rotate(0,90,0,90);

//		//Section 3 - Design Layout
		MI2 = new ModelInstance(hexagon,10,1,22);
		MI2.transform.scl(2.5f);

		MI1 = new ModelInstance(box,15,1,15); //object pos and size are equal

		MI3 = new ModelInstance(ramp,12,-2.5f,19);
		MI3.transform.scl(4); //I want this to be the bigger bridge
		MI3.transform.rotate(0,-90,0,90);

		//Section 4 - Design Layout
		MI28 = new ModelInstance(s4_plane,-25,-1,25);
		MI28.transform.scl(25);

		//Misc - Walls, Player Model etc.
		MI6 = new ModelInstance(main_plane,0,-1,0); // this should make the plane - sections 1-3
		MI6.transform.scl(50);

		MI7 = new ModelInstance(roof, 0,20,0); //this should make the roof.
		MI8 = new ModelInstance(m_wall,0,1,50); //right pos, wrong length etc.
		MI9 = new ModelInstance(m_wall,0,1,-50);
		MI10 = new ModelInstance(m_wall1,50,1,0);
		MI11 = new ModelInstance(m_wall1,-50,1,0);
		MI12 = new ModelInstance(playermodel,0, 1f, 5); //starts in same position as player.


		//Cone positions (to show distance)
		MI22 = new ModelInstance(cone,25,0,0);
		MI23 = new ModelInstance(cone,-25,0,0);
		MI24 = new ModelInstance(cone,0,0,25);
		MI25 = new ModelInstance(cone,0,0,-25);
		MI26 = new ModelInstance(cone,0,0,0);
		MI27 = new ModelInstance(cone,0, 10, 0);

		MI29 = new ModelInstance(donut,-11,4,15);
		MI29.transform.scl(20);
		MI31 = new ModelInstance(donut, -17,4,15);
		MI31.transform.scl(20);
		MI32 = new ModelInstance(donut, -14,4, 15);
		MI32.transform.scl(20);

		//bullet and AI
		MI30 = new ModelInstance(bullet,70,70,70); //this is just to set the bullet outside of the range of the playable area
		MI33 = new ModelInstance(AImodel,10,-1f,10);

		environment = new Environment(); //lighting
		environment.set(ambient); //set ambience

		//Lighting intensity may need to be changed with multiple lights
		environment.add(PL.set(0.8f, 0.8f, 0.8f, 2f, 10f, 2f, 20f)); //main light
		environment.add(PL1.set(0.8f, 0.8f, 0.8f,-25f,10f,-30f,20f)); //section 1 lighting
 		environment.add(PL2.set(0.8f, 0.8f, 0.8f,42f,10f,-40f,20f)); //section 2 lighting 41/42, 8, -40
		environment.add(PL3.set(0.8f, 0.8f, 0.8f,42f,10f,40f,20f)); //section 3 lighting 42, 8, 40
		environment.add(PL4.set(0.8f, 0.8f, 0.8f,-23f,10f,22f,20f)); //section 4 lighting -23, 8, 22
		//create the rest of the lighting, use draw-up for positions (not drawn to scale on paper)


		//audio
		SoundHandler.PlayAudio();

		//HUD camera setup (stops moving UI, and -z bug)
		UI.HUD(main_camera.position);

		input.setInputProcessor(this);

	}

	@Override
	public void render () {

		long start_time = System.nanoTime();
		long end_time = System.nanoTime() - start_time; //in theory is a 10ms increment.

		float timeElapsed = graphics.getDeltaTime();
		Vector3 v = main_camera.position.cpy();

		ScreenUtils.clear(0, 0, 0, 1); // clears screen
		gl.glClear(GL20.GL_COLOR_BUFFER_BIT|GL20.GL_DEPTH_BUFFER_BIT);// "" (to have multiple flags in a single integer value

		//Player models
		vector1 = main_camera.position;
		MI12 = new ModelInstance(playermodel,vector1); //this updates the playerposition model.

		//hardcoded instance_arr variables

		instance_arr_BB[0] = MI4; //objects in section 1
		instance_arr_BB[1] = MI13;
		instance_arr_BB[2] = MI14;
		instance_arr_BB[3] = MI15;
		instance_arr_BB[4] = MI16;

		//**
		//AI
		//**

		//takes AImodel which is just the player but is different because of sizing and positional changes
		//DT and the main camera position as a target.
		AI.followAI(timeElapsed, AImodel); //kinda works.

		//**********************
		//TEXTURING AND LIGHTING
		//**********************

		//fog script effect
		if(input.isKeyPressed(Input.Keys.F)){
			environment.set(fog);
		} else {environment.remove(ColorAttribute.Fog);}

		//Section 1 - Texturing
		if(input.isKeyPressed(Input.Keys.T)){ //needs to have some sort of button again to revert to not having textures.
			EnvironmentHandler.Texturing(MI17, Brick_Wall_M); //ramp objs
			EnvironmentHandler.Texturing(MI18, Brick_Wall_M);
			EnvironmentHandler.Texturing(MI19, Brick_Wall_M);

			//Section 2 - Texturing
			EnvironmentHandler.Texturing(MI, Brick_Wall_Red_M);
			EnvironmentHandler.Texturing(MI20, Brick_Wall_Red_M);

			//Section 3 - Texturing
			EnvironmentHandler.Texturing(MI3, Brick_Wall_Red_M);

			//Section 4 - Texturing

			//floor texturing
			EnvironmentHandler.Texturing(MI6, Red_Rocks_M);
			EnvironmentHandler.Texturing(MI28, Red_Rocks_M);

			//walls and ceiling
			EnvironmentHandler.Texturing(MI7, Metal_Wall_Plain_M); // ceiling
			EnvironmentHandler.Texturing(MI8, Metal_Wall_Red_Striped_M);
			EnvironmentHandler.Texturing(MI9, Metal_Wall_Red_Striped_M);
			EnvironmentHandler.Texturing(MI10, Metal_Wall_Red_M);
			EnvironmentHandler.Texturing(MI11, Metal_Wall_Red_M);

			//misc
			EnvironmentHandler.Texturing(MI29, Metal_Wall_Red_M);
			EnvironmentHandler.Texturing(MI31, Metal_Wall_Dark_M);
			EnvironmentHandler.Texturing(MI32, Wood_M);
		}


		//***********
		//Processes and External Method calls
		//***********

		PhysicsHandler.walking(timeElapsed);
		//PhysicsHandler.Freecam(timeElapsed);
		PhysicsHandler.dash(v, timeElapsed);
		PhysicsHandler.Gravity(timeElapsed);
		//PhysicsHandler.collisionDetector(instance_arr_BB, MI12); //nearly works, instance_arr is null when called, MI12 is playermodel
		PhysicsHandler.bullet(v,timeElapsed,bullet);
		PhysicsHandler.jump(timeElapsed);
		//CameraHandler.CameraMovement(timeElapsed); //camera movement.

		if(input.isKeyPressed(Input.Keys.L)){ //turns off environment, needs overhaul for all lights.
			environment.set(ambient);
			environment.add(PL.set(0.8f, 0.8f, 0.8f, 2f, 10f, 2f, 0f)); //main central light.
			environment.add(PL1.set(0.8f, 0.8f, 0.8f,-25f,10f,-30f,0f)); //section 1 lighting
			environment.add(PL2.set(0.8f, 0.8f, 0.8f,42f,10f,-40f,0f)); //section 2 lighting 41/42, 8, -40
			environment.add(PL3.set(0.8f, 0.8f, 0.8f,42f,10f,40f,0f)); //section 3 lighting 42, 8, 40
			environment.add(PL4.set(0.8f, 0.8f, 0.8f,-23f,10f,22f,0f)); //section 4 lighting -23, 8, 22
		} else {
			environment.set(ambient);
			environment.add(PL.set(0.8f, 0.8f, 0.8f, 2f, 10f, 2f, 20f));
			environment.add(PL1.set(0.8f, 0.8f, 0.8f,-25f,10f,-30f,20f)); //section 1 lighting
			environment.add(PL2.set(0.8f, 0.8f, 0.8f,42f,10f,-40f,20f)); //section 2 lighting 41/42, 8, -40
			environment.add(PL3.set(0.8f, 0.8f, 0.8f,42f,10f,40f,20f)); //section 3 lighting 42, 8, 40
			environment.add(PL4.set(0.8f, 0.8f, 0.8f,-23f,10f,22f,20f)); //section 4 lighting -23, 8, 22
		}

		main_camera.update();
		modelBatch.begin(main_camera);//camera as arg to begin positioning.
		modelBatch.render(MI, environment);//renders instance, and each object needs to pass the environment arg for lighting etc.
		modelBatch.render(MI1, environment); // can add seperate shader for arg
		modelBatch.render(MI2, environment);
		modelBatch.render(MI3, environment);
		modelBatch.render(MI4, environment);
		modelBatch.render(MI5, environment);
		modelBatch.render(MI6, environment);
		modelBatch.render(MI7, environment); //ceiling
		modelBatch.render(MI8, environment); //8 -11 walls
		modelBatch.render(MI9, environment);
		modelBatch.render(MI10, environment);
		modelBatch.render(MI11, environment);
		modelBatch.render(MI12); //playermodel - more efficient to not pass environment, no one can see it.
		modelBatch.render(MI13, environment);
		modelBatch.render(MI14, environment);
		modelBatch.render(MI15, environment);
		modelBatch.render(MI16, environment);
		modelBatch.render(MI17, environment); // ramp
		modelBatch.render(MI18, environment); //
		modelBatch.render(MI19, environment);
		modelBatch.render(MI20, environment);
		modelBatch.render(MI21, environment);
		modelBatch.render(MI22, environment);
		modelBatch.render(MI23, environment);
		modelBatch.render(MI24, environment);
		modelBatch.render(MI25, environment);
		modelBatch.render(MI26, environment);
		modelBatch.render(MI27, environment);
		modelBatch.render(MI28, environment);
		modelBatch.render(MI29, environment); //donut
		modelBatch.render(MI31, environment); //
		modelBatch.render(MI32, environment); // donut
		//modelBatch.render(b_instance); //bullet
		modelBatch.render(AI.AI_instance, environment);
		modelBatch.end();

		//**********
		//HUD and UI
		//**********

		SpriteBatch spriteBatch = new SpriteBatch();
		BitmapFont font = new BitmapFont(files.internal("MainFont.fnt"));

		spriteBatch.setProjectionMatrix(UI.UICamera.combined);
		spriteBatch.begin();

		spriteBatch.draw(Bar_Full, 700,-500); //Health bar
		font.draw(spriteBatch, "FPS: " + Gdx.graphics.getFramesPerSecond() + " - Player position: " + main_camera.position, -950, 500);
		font.draw(spriteBatch, "Health: " + PhysicsHandler.health, -950, -480); // static health variable instead
		font.draw(spriteBatch, "Ammo: " + PhysicsHandler.ammo, -700,-480); //ammo will change once shot, maybe auto ammo?
		font.draw(spriteBatch, "Collisions: " + PhysicsHandler.collisions, -525, -480); //shows collisions for debug
		spriteBatch.draw(Crosshair, -25,0);

		spriteBatch.end();

		//***********
		//HUD dispose
		//***********

		font.dispose();
		spriteBatch.dispose();

	}

	@Override //memory dump - Otherwise huge performance issues later.
	public void dispose() {
		//**************
		//Object Dispose
		//**************

		modelBatch.dispose();
		ramp_bridge2.dispose();
		box.dispose();
		sphere.dispose();
		J_plat.dispose();
		J_plat2.dispose();
		J_plat3.dispose();
		roof.dispose();
		m_wall.dispose();
		m_wall1.dispose();
		ramp.dispose();
		ramp_bridge.dispose();
		pyramid.dispose();
		hexagon.dispose();
		cone.dispose();
		bullet.dispose();
		donut.dispose();
		playermodel.dispose();
		AImodel.dispose();
		s4_plane.dispose();
		main_plane.dispose();

		//****************
		//Material Dispose - this maybe unnecessary, not sure if clearing them does anything for memory performanceMa
		//****************

		Metal_Wall_Red_M.clear();
		Floor_Gravel_M.clear();
		Metal_Wall_Plain_M.clear();
		Metal_Wall_Red_Striped_M.clear();
		Metal_Wall_Dark_M.clear();
		Brick_Wall_M.clear();
		Brick_Wall_Red_M.clear();
		Mountain_M.clear();
		Light_Wood_M.clear();
		Wood_M.clear();
		Red_Rocks_M.clear();

		//***************
		//Texture Dispose
		//***************

		Metal_Wall_Red_T.dispose();
		Floor_Gravel_T.dispose();
		Metal_Wall_Plain_T.dispose();
		Metal_Wall_Red_Striped_T.dispose();
		Metal_Wall_Dark_T.dispose();
		Brick_Wall_T.dispose();
		Brick_Wall_Red_T.dispose();
		Mountain_T.dispose();
		Light_Wood_T.dispose();
		Wood_T.dispose();
		Red_Rocks_T.dispose();

		//****
		//Misc
		//****

		Crosshair.dispose();
		Bar_Full.dispose();
		Bar_75.dispose();
		Bar_Half.dispose();
		Bar_25.dispose();
		Bar_Empty.dispose();

		SoundHandler.sound.dispose();

	}

	@Override
	public boolean keyDown(int keycode) {return false;}

	@Override
	public boolean keyUp(int keycode) {return false;}

	@Override
	public boolean keyTyped(char character) {return false;}

	@Override
	public boolean touchUp(int screenX, int screenY, int pointer, int button) {return false;}

	@Override
	public boolean touchDown(int screenX, int screenY, int pointer, int button) {return false;}

	@Override
	public boolean touchDragged(int screenX, int screenY, int pointer) {return false;}

	@Override //camera movement now here and fully functional.
	public boolean mouseMoved(int screenX, int screenY) {

		int magX = Math.abs(mouseX - screenX); //calculates magnitude of X
		int magY = Math.abs(mouseY - screenY); //and Y

		if (mouseX < screenX) {
			main_camera.rotate(Vector3.Y, -1 * magX * rotSpeed);
			main_camera.update();
		}

		if (mouseX > screenX) {
			main_camera.rotate(Vector3.Y, 1 * magX * rotSpeed);
			main_camera.update();
		}

		if (mouseY < screenY) {
			if (main_camera.direction.y > -0.965)
				main_camera.rotate(main_camera.direction.cpy().crs(Vector3.Y), -1 * magY * rotSpeed);
			main_camera.update();
		}

		if (mouseY > screenY) {

			if (main_camera.direction.y < 0.965)
				main_camera.rotate(main_camera.direction.cpy().crs(Vector3.Y), 1 * magY * rotSpeed);
			main_camera.update();
		}

		mouseX = screenX;
		mouseY = screenY;
		Gdx.input.setCursorCatched(true);
		return true;
	}

	@Override
	public boolean scrolled(float amountX, float amountY) {
		return false;
	}

}
