package com.mygdx.doom;

import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.math.Vector3;
import org.graalvm.compiler.lir.amd64.vector.AMD64VectorMove;

import java.util.Random;

import static com.mygdx.doom.CameraHandler.main_camera;

public class AI {
    public static ModelInstance AI_instance;
    private static Vector3 currentpos = new Vector3(10, -1f, 10);
    //might have to get the playerpos here and update it.
    public static void followAI(float timeElapsed, Model AI) {
        Vector3 target = main_camera.position;
        //just need to write a method here that an object is created in main, is attributed to a MI, imported here and update the position
        //over DT
        float speed = 8f;

        //player starts at 0,5 - Bot starts at 10,10
        AI_instance = new ModelInstance(AI, currentpos);//something like this to get the AI to the player target.

        if (currentpos != target) {
            Vector3 direction = new Vector3(target.x - currentpos.x, -1f, target.z - currentpos.z);
            direction.nor(); //normalises direction vector

            Vector3 desiredVel = new Vector3(direction.x * speed, -1f, direction.z * speed);
            Vector3 steeringforce = new Vector3(desiredVel.x - currentpos.x, -1f, desiredVel.z - currentpos.z);

            currentpos.x += (direction.x * timeElapsed);
            currentpos.z += (direction.z * timeElapsed);
            currentpos.y = -1f; //needs to stay at the same Y pos.
            AI_instance = new ModelInstance(AI, currentpos);

        } else{AI_instance = new ModelInstance(AI,Math.round(((float)Math.random()*10)), -1f, Math.round(((float)Math.random()*10)));}
             //resetting the target once the target is reached, not a final
    }
}

