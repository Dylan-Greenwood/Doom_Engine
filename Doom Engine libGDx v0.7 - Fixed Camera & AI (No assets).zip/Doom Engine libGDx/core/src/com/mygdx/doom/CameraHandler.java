package com.mygdx.doom;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.graphics.Cursor;
import com.badlogic.gdx.graphics.PerspectiveCamera;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.math.Vector3;

import static com.badlogic.gdx.Gdx.graphics;

public class CameraHandler extends Doom_Engine {
    //camera perspective, locking camera, cursor disappear, camera movement with mouse
    public static PerspectiveCamera main_camera;

    //main compiler for the Camera, will take methods relating to the Camera, including cursor stuff
    public static void CameraMaker() {
        main_camera = new PerspectiveCamera(90, graphics.getWidth(), graphics.getHeight()); //FOV and screen size
        main_camera.position.set(0f, 1f, 5f); //in something consistent like cm or metres or whatever (units??)
        main_camera.lookAt(0f, 1f, 0f);
        // makes viewing frustum
        main_camera.near = 0.1f;
        main_camera.far = 150f; //doesnt need to be huge as the level is only give or take 100/100

    }
    //no longer used, old version
    public static void CameraMovement(float timeElapsed){
        float rotatespeed = 0.005f; //direct correlation to mouse acceleration.
        float x = Gdx.input.getX();
        float y = Gdx.input.getY();
        float currenttime = Gdx.input.getCurrentEventTime();

        if (currenttime < timeElapsed){Gdx.input.setCursorPosition(0,0); currenttime = timeElapsed;}//reset pos

        if(x<1920 || x>0){
            main_camera.rotate(Vector3.Y, -x * (rotatespeed*10));
            Gdx.input.setCursorPosition(0,0);}

        if(Math.cos(y) <1 || Math.cos(y)>-1){
            main_camera.direction.y -= (y * rotatespeed);
            Gdx.input.setCursorPosition(0,0);}

        //reset pos here - needs to check if the previous x direction is the same as the current and if so will reset?
        if(currenttime >= Gdx.input.getCurrentEventTime() && x > x){x = 960; y = 540;}
            //MAYBE SOMETHING TO TELL if the camera position is moving and then an if to stop the movement.
            Gdx.input.setCursorCatched(true);
            //this works!!!!!!!
            //I think this is janky as it is keeping the pos at 0,0 and not the centre of the screen
            //x =960 middle
            //y = 540
        }
    }
