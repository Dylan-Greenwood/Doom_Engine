package com.mygdx.doom;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Camera;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.math.Vector3;

public class UI {
    public static Camera UICamera;


    public static void HUD(Vector3 position){
        //where position is the main camera position
        UICamera = new OrthographicCamera(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        //think this need to change with the position of the main camera.

        UICamera.position.set(position);
        UICamera.update();
        //kinda works renders outside of the scope


        //https://www.youtube.com/watch?v=ELkqiMpvMLA
        //downloaded and referenced Font used.
        //https://stackoverflow.com/questions/62115541/displaying-fps-in-libgdx-game

    }

    //This will create a copy of the perspective camera to then add UI effects
    //such as health, ammo, etc.

}
