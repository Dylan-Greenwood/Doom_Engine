package com.mygdx.doom;

import com.badlogic.gdx.graphics.g3d.Material;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.model.Node;
import com.badlogic.gdx.graphics.g3d.model.NodePart;
import com.badlogic.gdx.graphics.g3d.particles.ParticleSystem;
import com.badlogic.gdx.graphics.g3d.particles.batches.PointSpriteParticleBatch;


public class EnvironmentHandler extends Doom_Engine{

    public static void Texturing(ModelInstance instance, Material material){ // Takes a texture object to then process onto an actual object.
        for (int i = 0; i < instance.nodes.size; i++) {
            Node node = instance.nodes.get(i);
            for (int j = 0; j < node.parts.size; j++) {
                NodePart nodePart = node.parts.get(j);
                nodePart.material = material;
            }
        }
    }
    public static void Array_Texturing(ModelInstance instance_arr[], Material material){
        for (int i =0; i < instance_arr.length; i++){
            for (int l = 0; l < instance_arr[l].nodes.size; l++) {
                Node node = instance_arr[l].nodes.get(l);
                for (int j = 0; j < node.parts.size; j++) {
                    NodePart nodePart = node.parts.get(j);
                    nodePart.material = material;
                }
            }
        }
    }
    //maybe it should take a list of all ModelInstances and pass that through the method, to then texture
    //either need to make/invoke different methods for different texturing or handle it all in this.


    //To texture we need to use mashpartbuilders which then create triabngle object meshes inside of the object to
    //then render the object in terms of those triangle objects.

    //can create pixmaps later on to import/ create textures using the engine, via actual pixel coords
    //You can manipulate pixels in a pixmap to each individually be any colour you want.

//    public void Particles(){
//        //basics of particle effects.
//        ParticleSystem particleSystem = new ParticleSystem();
//        // Since our particle effects are PointSprites, we create a PointSpriteParticleBatch
//        PointSpriteParticleBatch pointSpriteBatch = new PointSpriteParticleBatch();
//        pointSpriteBatch.setCamera(CameraHandler.main_camera);
//        particleSystem.add(pointSpriteBatch);
//        particleSystem.draw();
//        particleSystem.end();
//    }
}
