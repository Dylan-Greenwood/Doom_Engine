package com.mygdx.doom;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.g3d.Model;
import com.badlogic.gdx.graphics.g3d.ModelInstance;
import com.badlogic.gdx.graphics.g3d.model.Node;
import com.badlogic.gdx.math.Vector3;
import com.badlogic.gdx.math.collision.BoundingBox;

import static com.mygdx.doom.CameraHandler.main_camera;
import static com.mygdx.doom.Doom_Engine.modelBatch;

//http://xoppa.github.io/

//class for physics, collisions, gravity, movement - objects.
public class PhysicsHandler {
    private static float speed = 5f; //values not 100% for final release
    public static int health = 100;
    public static int ammo = 8;
    public static int collisions = 0;
    public static ModelInstance b_instance;
    public static void Gravity(float timeElapsed){ //all objects should just float down if raises above the plane at a certain speed.
        float g = 0.981f; //gravity variable
        float x_pos = 0;
        Vector3 vector = new Vector3(0,0,0);

        float vel = 3f; //can either be const or varied, const for testing
        float fin_pos; //final pos.
//        if(main_camera.position.y >= 1.01){ //operates for too many frames.
//            main_camera.position.y =- 0.1f;
//        }
        //if position is above 1, then the objects must come down at a rate every frame

        fin_pos = (float) ((x_pos) + (vel*timeElapsed) + (0.5*g*timeElapsed*2)); //same for each, or Vector instead.
        //this needs to essentially every frame that the player is above 0.9/1f the player is to gain 0.25f~ every frame...
        //in exactly the same way as the position decreases by 0.1 every

    /*
    The formula xf = x0 + v0*t + (1/2)*g*t^2 will give you the final position xf given the initial position x0,
    the initial (vertical) velocity v0 and the time t that the object has been falling.
    g is a constant that technically depends a bit on your elevation and other factors, but is around 9.81 m/s.

     */
    }
    public static void jump(float timeElapsed){ //need
        float temptime = 0;
        if(Gdx.input.isKeyJustPressed(Input.Keys.SPACE) && main_camera.position.y >= 0.9
                && main_camera.position.y <=1.1f){ //jump for the player (need to be just pressed or spam)
            main_camera.position.y += 3f;
        }

        if(main_camera.position.y > 1 && timeElapsed > temptime){ //needs to be put into gravity.
            main_camera.position.y -= 0.075f; //falls correctly
        }
    }

    public static void collisionDetector(ModelInstance instance_arr[], ModelInstance player){
        //needs to take list of objects, go through each of them for the Nodes/vertices and then apply bounding boxes to the correct objs
        BoundingBox BB = new BoundingBox();
        BoundingBox Player_BB = new BoundingBox();
        player.calculateBoundingBox(Player_BB); //calculates BB for the player.

        for (int i = 0; i < instance_arr.length; i++) { //maybe the BB is applying to all the walls, but has added the map as a BBq
            instance_arr[i].calculateBoundingBox(BB); //based on the vertices of the modelinstance, creates boundingn box
            //need to have a different BB for the player, so that it can check intersection.
            if(BB.contains(Player_BB)){ //maybe not the main_camera position, or the BB is being created wrong.
                //detection stuff for the player.
               collisions += 1; //just to check for collision
            }
            BB.clr();
            Player_BB.clr();
            //need a statement to check whether BB's are within each other.
        }
    }

        //need to create go through objects to then create the BB of them
//        if(BB.isValid()){
//            System.out.println("BoundingBox successfully created, and valid");
//        } else {System.out.println("BoundingBox not created. Try again.");}



        //Interpolation.Bounce.bounceIn.apply(2); bounce??
        //BoundingBox() - Creates the boundingbox collision physics by min and max vector
        //basic bounding box collision, if 2 objects interact then a collision is had.
        //needs to be able to get the positions of objects - including the player
        //to then be able to see if the positions overlap, if they do
        //then it will be decided in another method what should happen e.g. death etc.

    public static boolean isHit(ModelInstance MI){return true;}

    public static boolean isDestroyed(ModelInstance MI){return true;} //moves or gets rid of the object once it has been destroyed.

    public static void Freecam(float timeElapsed){ //to be invoked for demonstration purposes, needs to invoke every frame but can't as static
        float fc_speed = 25f;
        if(Gdx.input.isKeyPressed(Input.Keys.W)){
            Vector3 v = main_camera.direction.cpy();
            //v.y = fc_speed * timeElapsed;
            v.x *= fc_speed * timeElapsed;
            v.z *= fc_speed * timeElapsed;
            main_camera.translate(v);
            main_camera.update();
        }
        if(Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)){
            fc_speed = 50f;
        }
    }

    public static void walking(float timeElapsed) {

        //stops the engine giving the player additional speed when pressing 2 buttons
        if ((Gdx.input.isKeyPressed(Input.Keys.W)| Gdx.input.isKeyPressed(Input.Keys.S)) &
                (Gdx.input.isKeyPressed(Input.Keys.D)| Gdx.input.isKeyPressed(Input.Keys.A))) {speed /= Math.sqrt(2);}

        if (Gdx.input.isKeyPressed(Input.Keys.W)) {
            //W input
            Vector3 v = main_camera.direction.cpy();
            v.y = 0f;
            v.x *= speed * timeElapsed;
            v.z *= speed * timeElapsed;
            main_camera.translate(v);
            main_camera.update();
        }
        if (Gdx.input.isKeyPressed(Input.Keys.S)) {
            //S input
            Vector3 v = main_camera.direction.cpy();
            v.y = 0f;
            v.x = -v.x;
            v.z = -v.z;
            v.x *= speed * timeElapsed;
            v.z *= speed * timeElapsed;
            main_camera.translate(v);
            main_camera.update();
        }
        if (Gdx.input.isKeyPressed(Input.Keys.A)) {
            //A input
            Vector3 v = main_camera.direction.cpy();
            v.y = 0f;
            v.rotate(Vector3.Y, 90);
            v.x *= speed * timeElapsed;
            v.z *= speed * timeElapsed;
            main_camera.translate(v);
            main_camera.update();
        }
        if (Gdx.input.isKeyPressed(Input.Keys.D)) {
            //D input
            Vector3 v = main_camera.direction.cpy();
            v.y = 0f;
            v.rotate(Vector3.Y, -90);
            v.x *= speed * timeElapsed;
            v.z *= speed * timeElapsed;
            main_camera.translate(v);
            main_camera.update();

        }
    }
    public static void dash(Vector3 v, float timeElapsed){
        int temptime = 5;
        float currenttime = timeElapsed;

        if(Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT) && currenttime != temptime){speed = 25f; currenttime+= timeElapsed;}
        else {speed = 5f;} //sprint movement - default 10

        if(Gdx.input.isKeyJustPressed(Input.Keys.R)){
            v = main_camera.direction.cpy();
            v.x *= speed+timeElapsed;
            v.z *= speed+timeElapsed;
            v.y = 0f;

            main_camera.translate(v);
            main_camera.update();
        }
    }

    public static void bullet(Vector3 v, float timeElapsed, Model bullet){

        if(Gdx.input.isButtonPressed(Input.Buttons.LEFT)){
           v = main_camera.position.cpy();
           v.x *= speed + timeElapsed;
           v.y *= speed + timeElapsed;
           v.z *= speed + timeElapsed;
            modelBatch.render(b_instance); //can't render here - probably why it won't stay rendered.
            ammo -= 1;

            if(ammo <= 0){
                ammo = 8;
                //have something here to reload/regenerate ammo
            }
            //batch in here, create instance here.
           //this does in theory work, but causes the engine to crash.
        }
    }
}

