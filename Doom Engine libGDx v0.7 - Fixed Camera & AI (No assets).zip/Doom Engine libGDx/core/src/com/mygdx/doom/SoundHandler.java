package com.mygdx.doom;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.audio.Sound;

public class SoundHandler {
    static Sound sound;
    public static void PlayAudio() {
        sound = Gdx.audio.newSound(Gdx.files.internal("assets/WindAmbience16bit.wav")); //ultrakill music here

        sound.play(1f); //plays the audio

    }


}
