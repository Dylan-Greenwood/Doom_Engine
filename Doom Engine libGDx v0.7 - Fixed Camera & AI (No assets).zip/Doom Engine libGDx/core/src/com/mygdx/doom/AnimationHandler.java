package com.mygdx.doom;

import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g3d.utils.AnimationController;

public class AnimationHandler {
    private Animation animation;
    private AnimationController animationController;

    public void Animation(){
        //handles animation
    }

}
