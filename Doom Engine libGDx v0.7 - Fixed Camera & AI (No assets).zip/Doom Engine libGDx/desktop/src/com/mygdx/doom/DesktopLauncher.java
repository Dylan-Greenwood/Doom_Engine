package com.mygdx.doom;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;

// Please note that on macOS your application needs to be started with the -XstartOnFirstThread JVM argument
public class DesktopLauncher{
	public static void main (String[] arg) {
		Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
		config.setMaximized(true);
		config.setWindowSizeLimits(1280,720, 1920,1080); //max and min for screen
		config.setForegroundFPS(144); //does this matter that much right now?
		config.useVsync(true);//should in theory display at hz of screen.
		config.setTitle("Doom Engine");
		new Lwjgl3Application(new Doom_Engine(), config);
	}
}
